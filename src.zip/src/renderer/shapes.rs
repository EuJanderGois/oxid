// src/renderer/shapes.rs

use crate::renderer::{color::Color, MqRenderer};

pub trait ShapesAPI {
    fn draw_circle(&mut self, x: f32, y: f32, radius: f32, color: Color);
}

pub struct MqShapes<'a> {
    renderer: &'a mut MqRenderer,
}

impl ShapesAPI for MqShapes<'_> {
    fn draw_circle(&mut self, x: f32, y: f32, radius: f32, color: Color) {
        use macroquad::prelude::{draw_circle, Color as MqColor};
        let _ = &mut self.renderer; // reserva espaço para estado futuro
        draw_circle(x, y, radius, MqColor::new(color.r, color.g, color.b, color.a));
    }
}