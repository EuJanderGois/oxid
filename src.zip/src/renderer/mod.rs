// src/renderer/mod.rs

pub mod shapes;
pub mod color;

use crate::renderer::{color::Color, shapes::{MqShapes, ShapesAPI}};

pub trait Renderer {
    type Shapes<'a>: ShapesAPI
    where 
        Self: 'a;

    fn begin_frame(&mut self);
    fn delta_time(&self) -> f32;
    fn clear_bg(&self, color: Color);
}

pub struct MqRenderer;

impl Renderer for MqRenderer {

    type Shapes<'a> = MqShapes<'a>;
    
    fn begin_frame(&mut self) {
        todo!()
    }

    fn delta_time(&self) -> f32 {
        use macroquad::prelude::*;
        get_frame_time()
    }
    
    fn clear_bg(&self, color: Color) {
        use macroquad::prelude::{clear_background, Color as MqColor};
        clear_background(MqColor::new(
            color.r, color.g, color.b, color.a));
    }
}