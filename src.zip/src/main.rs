use oxid::scripting::ScriptEngine;
use oxid::renderer::{MqRenderer, Renderer, color::DARKGRAY};

#[macroquad::main("Modular Scripting")]
async fn main() {
    let script = r#"
        import { GameObject } from "oxid/core";
        import { Transform2D } from "oxid/math";
        import { drawCircle } from "oxid/graphics";

        export class MyApp extends GameObject {
            
            constructor() {
                super();
                this.jogador = new Transform2D(100.0, 100.0);
                this.velocidade = 24.0;
            }

            onUpdate(dt) {
                this.jogador.x += this.velocidade * dt;

                if (this.jogador.x > 800.0) {
                    this.jogador.x = 0;
                }
            }

            onDraw() {
                drawCircle(this.jogador.x, this.jogador.y, 25.0);
            }
        }

        export function main() {
            return new MyApp();
        }
    "#;

    let renderer: MqRenderer = MqRenderer;
    let engine = ScriptEngine::new(script);
    
    engine.on_init();

    loop {
        let dt = renderer.delta_time();
        engine.on_update(dt);

        renderer.clear_bg(DARKGRAY);
        engine.on_draw();

        macroquad::prelude::next_frame().await;
    }
}